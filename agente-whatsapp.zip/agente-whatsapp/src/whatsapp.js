// O unico arquivo que toca a biblioteca do WhatsApp.
//
// POR QUE ISOLADO ATE ESTE PONTO
// ------------------------------
// whatsapp-web.js dirige um navegador de verdade rodando o WhatsApp Web. Isso
// significa duas coisas incomodas: (1) e um cliente NAO OFICIAL, que quebra
// quando o WhatsApp Web muda de layout; (2) nada aqui roda em teste, porque
// exigiria um celular pareado. Entao este arquivo e propositalmente burro — ele
// so traduz eventos e chamadas. Toda decisao mora em `nucleo.js`, que roda
// inteiro em teste.
//
// O QUE E INCERTO NESTA BIBLIOTECA, E COMO O CODIGO SE PROTEGE
// ------------------------------------------------------------
// · `message_create` deveria cobrir mensagem recebida E enviada. Como nao da
//   para confirmar aqui, o `message` tambem e escutado, e a fila local descarta
//   a duplicata pela chave. Escutar os dois custa nada; escutar so o errado
//   custa metade da conversa do dono.
// · Mensagem enviada pelo CELULAR (e nao por este programa) deveria chegar como
//   evento de dispositivo pareado. Se nao chegar, a varredura de historico da
//   proxima reconexao pega — e por isso a varredura tambem existe.
// · `getState()` as vezes lanca quando o navegador ainda esta subindo, entao
//   ninguem aqui depende dele: o estado vem dos EVENTOS, que sao confiaveis.

import qrcode from "qrcode-terminal";
import wweb from "whatsapp-web.js";
import { jidDoTelefone } from "./telefone.js";

const { Client, LocalAuth } = wweb;

/** Teto de mensagens lidas por conversa na varredura. Sem teto, uma conversa
 *  antiga de anos trava o navegador embutido e o programa parece pendurado. */
export const TETO_MENSAGENS_POR_CONVERSA = 100;

/** Teto de conversas varridas. Quem tem 2000 conversas abertas não precisa
 *  delas todas no CRM — precisa das que tiveram movimento agora. */
export const TETO_CONVERSAS = 300;

/** Quantas quedas seguidas antes de deixar o launchd reiniciar tudo. Reerguer
 *  o navegador embutido em cima de si mesmo é a parte menos confiável desta
 *  biblioteca; processo novo é sempre estado limpo. */
export const QUEDAS_ANTES_DE_DESISTIR = 5;

/**
 * Achata a mensagem da biblioteca num objeto simples.
 *
 * Serve para o resto do programa nunca segurar um objeto vivo da biblioteca:
 * esses objetos carregam referência ao navegador, e guardá-los numa fila em
 * disco (ou em memória por horas) é vazamento garantido.
 */
function achatar(msg, nomeExibicao) {
  return {
    id: msg?.id,
    from: msg?.from,
    to: msg?.to,
    fromMe: msg?.fromMe,
    body: msg?.body,
    timestamp: msg?.timestamp,
    type: msg?.type,
    isStatus: msg?.isStatus,
    _nomeExibicao: nomeExibicao ?? "",
  };
}

export function criarWhatsapp({ config, log, aoCapturar, aoConectar }) {
  let pronto = false;
  let qrPendente = false;
  // A STRING do QR, e não só o "precisa de QR". Ela sobe junto com o pulso
  // para o CRM desenhar o código na tela em que o dono já está trabalhando —
  // antes disso, conectar exigia ler um QR de caracteres dentro do Terminal,
  // o que serve para quem programa e trava todo mundo mais.
  let qrAtual = null;
  let quedas = 0;
  let cliente = null;

  /**
   * O nome que aparece na agenda. Envolvido em try/catch porque é uma ida ao
   * navegador que falha por motivo bobo (contato apagado, conversa arquivada) —
   * e perder a mensagem inteira por causa do NOME seria trocar o essencial pelo
   * decorativo.
   */
  async function nomeDoContato(msg) {
    try {
      const contato = await msg.getContact();
      return contato?.pushname || contato?.name || contato?.verifiedName || "";
    } catch {
      return "";
    }
  }

  async function capturarUma(msg) {
    try {
      const nome = msg?.fromMe === true ? "" : await nomeDoContato(msg);
      await aoCapturar([achatar(msg, nome)]);
    } catch (erro) {
      // Exceção dentro de listener de evento derruba o listener em silêncio, e
      // o dono continua achando que está capturando. Nada sobe daqui.
      log.erro("Falha ao capturar uma mensagem que chegou.", erro);
    }
  }

  function montarCliente() {
    const c = new Client({
      // LocalAuth guarda a sessão em disco: é o que faz o QR aparecer uma vez
      // só, e não toda manhã quando o dono liga o notebook.
      authStrategy: new LocalAuth({ clientId: "raro", dataPath: config.pastaSessao }),
      puppeteer: {
        headless: true,
        // Estas flags reduzem consumo no Mac do dono, que está usando a
        // máquina para trabalhar enquanto isto roda no fundo.
        args: ["--disable-gpu", "--disable-dev-shm-usage", "--no-first-run"],
      },
    });

    c.on("qr", (qr) => {
      qrPendente = true;
      qrAtual = typeof qr === "string" ? qr : null;
      pronto = false;
      log.aviso("Precisa ler o QR Code no WhatsApp do celular (Aparelhos conectados).");
      try {
        qrcode.generate(qr, { small: true });
      } catch (erro) {
        // Sem terminal (subiu pelo launchd) o desenho falha. O texto cru ainda
        // permite gerar o QR por outro meio, então ele não pode sumir.
        log.aviso("Não consegui desenhar o QR aqui. Rode `./parar.command` e depois abra o Terminal.", erro);
      }
    });

    c.on("authenticated", () => {
      qrPendente = false;
      // O código já foi usado: apagar da memória evita que uma batida atrasada
      // publique no CRM um QR que não vale mais nada.
      qrAtual = null;
      log.info("WhatsApp autenticado.");
    });

    c.on("auth_failure", (motivo) => {
      // Sessão inválida costuma exigir QR de novo; dizer isso é mais útil que
      // o texto interno da biblioteca.
      pronto = false;
      qrPendente = true;
      log.erro("A sessão do WhatsApp foi recusada. Vai precisar ler o QR de novo.", motivo);
    });

    c.on("ready", () => {
      pronto = true;
      qrPendente = false;
      qrAtual = null;
      quedas = 0;
      log.info("WhatsApp conectado e pronto.");
      Promise.resolve(aoConectar?.()).catch((erro) =>
        log.erro("Falha ao sincronizar o histórico depois de conectar.", erro)
      );
    });

    c.on("disconnected", (motivo) => {
      pronto = false;
      quedas += 1;
      log.aviso(`WhatsApp desconectou (${String(motivo ?? "sem motivo")}). Tentativa ${quedas}.`);
      if (quedas >= QUEDAS_ANTES_DE_DESISTIR) {
        // Sair com erro é pedir ao launchd um processo novo. É mais confiável
        // que insistir em reerguer o navegador embutido em cima do estado sujo.
        log.erro("Muitas quedas seguidas. Encerrando para o macOS subir o agente de novo.");
        setTimeout(() => process.exit(1), 1000);
      }
    });

    // Os dois eventos de propósito: ver o comentário do topo do arquivo.
    c.on("message_create", capturarUma);
    c.on("message", capturarUma);

    return c;
  }

  return {
    estaPronto: () => pronto === true,
    precisaQr: () => qrPendente === true,
    qrAtual: () => qrAtual,

    async iniciar() {
      cliente = montarCliente();
      await cliente.initialize();
    },

    /**
     * Manda o texto e devolve o id que o WhatsApp deu à mensagem.
     *
     * Lança quando não dá para enviar, e quem chama transforma isso em
     * `ResultadoEnvio` com `enviado: false` — o CRM precisa saber que NÃO saiu,
     * e não pode ficar com uma linha pendurada na fila para sempre.
     */
    async enviarTexto(telefone, texto) {
      if (!pronto || !cliente) throw new Error("A sessão do WhatsApp não está aberta.");

      const jid = jidDoTelefone(telefone);
      if (jid === "") throw new Error("Telefone em formato que não dá para discar.");

      // Conferir se o número existe no WhatsApp antes de mandar. Está dentro de
      // try/catch porque a confirmação é menos confiável que o envio: quando a
      // checagem falhar por conta própria, o certo é tentar mandar assim mesmo.
      try {
        const registrado = await cliente.getNumberId(jid);
        if (registrado === null) throw new Error("Este número não tem WhatsApp.");
      } catch (erro) {
        if (erro instanceof Error && erro.message === "Este número não tem WhatsApp.") throw erro;
      }

      const enviada = await cliente.sendMessage(jid, texto);
      return { idExterno: enviada?.id?._serialized ?? "" };
    },

    /**
     * Varre o que aconteceu enquanto o notebook estava fechado.
     *
     * A biblioteca não sabe buscar "mensagens desde tal data": ela devolve as N
     * últimas de cada conversa. Então o corte por data é feito aqui, depois de
     * ler — e o `limit` existe para a leitura não virar um mergulho em anos de
     * conversa que trava o navegador embutido.
     */
    async varrerHistorico(desdeMs) {
      if (!pronto || !cliente) return { conversas: 0, mensagens: 0 };

      let conversas = 0;
      let mensagens = 0;

      let lista = [];
      try {
        lista = await cliente.getChats();
      } catch (erro) {
        log.erro("Não consegui listar as conversas para varrer o histórico.", erro);
        return { conversas: 0, mensagens: 0 };
      }

      for (const chat of lista.slice(0, TETO_CONVERSAS)) {
        // Grupo é descartado na origem: mensagem de grupo não pertence à ficha
        // de nenhum cliente e só gastaria rede para o servidor jogar fora.
        if (chat?.isGroup === true) continue;

        try {
          const brutas = await chat.fetchMessages({ limit: TETO_MENSAGENS_POR_CONVERSA });
          const recentes = (Array.isArray(brutas) ? brutas : []).filter(
            (m) => Number(m?.timestamp ?? 0) * 1000 >= desdeMs
          );
          if (recentes.length === 0) continue;

          const nome = String(chat?.name ?? "");
          await aoCapturar(recentes.map((m) => achatar(m, m?.fromMe === true ? "" : nome)));
          conversas += 1;
          mensagens += recentes.length;
        } catch (erro) {
          // Uma conversa problemática não pode interromper a varredura das
          // outras: seria uma conversa estragando o histórico inteiro.
          log.aviso("Não consegui ler uma das conversas no histórico.", erro);
        }
      }

      return { conversas, mensagens };
    },

    async parar() {
      pronto = false;
      try {
        await cliente?.destroy();
      } catch (erro) {
        // Já estamos saindo: falhar ao fechar o navegador não muda nada além
        // do texto do log.
        log.aviso("O navegador do WhatsApp não fechou direito.", erro);
      }
    },
  };
}
